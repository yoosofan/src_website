using System;

static class testCls{
	
		static void Main(){
			string line1;
			int i=1,j=2,k=3;
			line1 = Console.ReadLine();
			while (line1 != null ){
				int m;
				switch(line1){
					case "0":
						m=f1();
					break;
					case "1":
						m=f1(i);
					break;
					case "2":
						m=f1(i,j);
					break;
					case "3":
						m=f1(i,j,k);
					break;
					default:
						m=f1();
					break;
				}
				Console.WriteLine("{0}", m);
				Console.WriteLine("{0}",mf2(n:m,a:1));
				line1=Console.ReadLine();
			}
		}
		static int f1(params int[] l1){
			int ret=1;
			for(int i=0;i<l1.Length;i++)
				ret *= l1[i];
			return ret;
		}
		
		static int mf2(int a , int n){
			aaaa=1;
			int retVal=1;
			for(;n>0;n--)
				retVal += a;
			return retVal+nnn;
		}
		static int nnn=1;
		public static int aaaa {get; private set;} 
		
}
