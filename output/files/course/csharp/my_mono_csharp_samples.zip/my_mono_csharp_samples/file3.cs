using System;
using System.IO;
class ShowFile {
   static void Main(string[] args) {
      int i;
      FileStream fin = null;
      string fileName;
      if(args.Length < 1) {
         Console.WriteLine("Enter name of file :");
         fileName = Console.ReadLine();
         if(fileName.Trim() == "")  // Trim removes white space in a string
            fileName = "file3.cs";
      }
      else
         fileName = args[0];
      // Use a single try block to open the file and then
      // read from it.
      try {
         fin = new FileStream(fileName, FileMode.Open);
         // Read bytes until EOF is encountered.
         do {
            i = fin.ReadByte();
            if(i != -1) Console.Write((char) i);
         } while(i != -1);
      }
      catch(IOException exc) {
         Console.WriteLine("I/O Error:\n" + exc.Message);
      }
      finally {
         if(fin != null) fin.Close();
      }
   }
}

