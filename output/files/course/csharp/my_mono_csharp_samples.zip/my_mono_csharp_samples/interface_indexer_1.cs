using System;
using System.Threading;
//using System.Threading.Tasks;
interface ImySimple{
	int fun1();
	int this[double index]{
		set;
		get;
	}
	int Next { set; get;}
}
class implementImyCls : ImySimple{
	public implementImyCls(int m=0){val = m;}
	int val;
	public int Next {
		set {val = value>0 ? value : 0;}
		get {val+=2; return val;}
	}
	public int fun1() {return Next;}
	public int this[double index]{
		set{Next = (int) value;}
		get{Next = (int) index; return Next;}
	}
	
}
class secondImyCls : ImySimple{
	public secondImyCls(){Next = 1;}
	public int fun1(){Next = 0; return Next;}
	public int this[double index]{
		set{Next = value >0 ? value : 1;}
		get{return Next;}
	}
	public int Next{
		set{Next = value;}
		get{return Next;}
	}
}
class testCls{
	static void Main(){
		implementImyCls c1 = new implementImyCls();
		Console.WriteLine("{0}", c1.Next);
		Console.WriteLine("{0}", c1.Next);		
		c1[5]=12;
		Console.WriteLine("{0}", c1.Next);		
		Console.WriteLine("{0}", c1[5.4]);
		Console.WriteLine("{0}", c1.Next);		
		Console.WriteLine("{0}",c1.fun1());
		secondImyCls s1 = new secondImyCls();
		Console.WriteLine("{0}",s1.Next);
	}
}
