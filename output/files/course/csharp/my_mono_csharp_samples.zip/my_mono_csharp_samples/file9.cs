/*
void Write(sbyte value) Writes a signed byte.
void Write(byte value) Writes an unsigned byte.
void Write(byte[ ] buffer) Writes an array of bytes.
void Write(short value) Writes a short integer.
void Write(ushort value) Writes an unsigned short integer.
void Write(int value) Writes an integer.
void Write(uint value) Writes an unsigned integer.
void Write(long value) Writes a long integer.
void Write(ulong value) Writes an unsigned long integer.
void Write(float value) Writes a float.
void Write(double value) Writes a double.
void Write(decimal value) Writes a decimal.
void Write(char ch) Writes a character.
void Write(char[ ] chars) Writes an array of characters.
void Write(string value) Writes a string using its internal representation, which includes a
                        length specifier.


int Read( ) Returns an integer representation of the next
           available character from the invoking input
          stream. Returns –1 when attempting to read at
           the end of the file.
int Read(byte[ ] buffer, int index, int count) Attempts to read up to count bytes into buffer
                                              starting at buffer[index], returning the number of
                                             bytes successfully read.
int Read(char[ ] buffer, int index, int count) Attempts to read up to count characters into
                                              buffer starting at buffer[index], returning the
                                             number of characters successfully read.
bool ReadBoolean( ) Reads a bool.
byte ReadByte( ) Reads a byte.
sbyte ReadSByte( ) Reads an sbyte.
byte[ ] ReadBytes(int count) Reads count bytes and returns them as an array.
char ReadChar( ) Reads a char.
char[ ] ReadChars(int count) Reads count characters and returns them as an array.
decimal ReadDecimal( ) Reads a decimal.
double ReadDouble( ) Reads a double.
float ReadSingle( ) Reads a float.
short ReadInt16( ) Reads a short.
int ReadInt32( ) Reads an int.
long ReadInt64( ) Reads a long.
ushort ReadUInt16( ) Reads a ushort.
uint ReadUInt32( ) Reads a uint.
ulong ReadUInt64( ) Reads a ulong.
string ReadString( ) Reads a string that is represented in its internal, binary
                    format, which includes a length specifier. This method
                   should only be used to read a string that has been written
                  using a BinaryWriter.



SeekOrigin.Begin Seek from the beginning of the file.
SeekOrigin.Current Seek from the current location.
SeekOrigin.End Seek from the end of the file.

*/
class file9Cls{
   static void Main(){}
}