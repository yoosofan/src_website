// From http://live.gnome.org/Vala/ValaForCSharpProgrammers
using System;

delegate void SomeEventHandler(object sender, int i);

class Foo
{
    public event SomeEventHandler SomeEvent;

    public void RaiseSomeEvent(int i)
    {
        if (SomeEvent != null) SomeEvent(this, i);
    }
}

class Demo
{
    static void OnSomeEvent(object sender, int i)
    {
        Console.WriteLine("Handler A: " + i);
    }

    static void Main()
    {
        var foo = new Foo();
        foo.SomeEvent += OnSomeEvent;
        foo.SomeEvent += (s, i) => Console.WriteLine("Handler B: " + i);
        foo.RaiseSomeEvent(42);
        foo.SomeEvent -= OnSomeEvent;
    }
}
//int? i = null;
