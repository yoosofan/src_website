delegate void IntView(int v);
class TestDelegate2 {
	public static void Main() {
		IntView i, x, c, ic, all;
		i = delegate(int v) { System.Console.Write("’{0}’ ", (char)v); };
		x = delegate(int v) { System.Console.Write("0x{0:X} ", v); };
		c = delegate(int v) { System.Console.Write("{0} ", v); };
		System.Console.Write("\ni: "); i(32);
		System.Console.Write("\nx: "); x(32);
		System.Console.Write("\nc: "); c(32);
		all=i+x+c; // callbacks in that order
		System.Console.Write("\nall: "); all(32);
		ic = all - x;
		System.Console.Write("\nic: "); ic(32);
	}
}
