class complexCls {
   public double real;
   public double img;
   }
class linkedList{
   class Node{
      public complexCls data;
      public Node link = null;
      }
   private Node head = null;
   public void insert_first(complexCls a){
      Node p= head;
      head = new Node();
      head.data = a;
      head.link = p;
   }
   public void insert(int index , complexCls a){
      Node temp = new Node(); Node c=head;
      temp.data = a;
      for(int i=1;i<index && c.link != null ; i++, c=c.link);
      temp.link = c.link;
      c.link=temp;
   }
   public void display(){
      System.Console.WriteLine("Print of data link list");
      for(Node n1 = head;n1 != null; n1 = n1.link)
         System.Console.WriteLine("{0}  {1} ", n1.data.real , n1.data.img);
      }
}
class Main1{
   public static void Main(){
      linkedList l1 = new linkedList();
      complexCls a1=new complexCls();
      a1.real = 1;    a1.img  =12;
      l1.insert_first(a1);
      a1 = new complexCls();
      a1.real = 5;   a1.img = 6;
      l1.insert_first(a1);
      a1=new complexCls();
      a1.real = 7;   a1.img = 8;
      l1.insert(1,a1);
      a1=new complexCls();
      a1.real = 12; a1.img = 40;
      l1.insert(1,a1);
      l1.display();
   }
}
