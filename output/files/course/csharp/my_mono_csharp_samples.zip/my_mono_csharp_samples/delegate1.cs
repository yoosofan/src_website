using System;
delegate int myfDelegate(int i);
class Delegate1Cls{
   static int f1(int i){ return i;}
   static int f2(int i){ return i+1;}
   static int f3(int j){ return j-1;}
   static void Main(){
      myfDelegate myf = f1;
      int k=1 ;
      k=myf(k);
      Console.WriteLine("11: " + k);
      myf = f2;
      k=myf(k);
      Console.WriteLine("14: "+k);
      myf = new myfDelegate(f3); // You can use new for assigning new function to this delegate
      k=myf(k);
      Console.WriteLine("15: "+k);
      myfDelegate[] amyf = {f1 , f2 , f3};
      foreach(myfDelegate my1 in amyf)
         Console.WriteLine("20: "+my1(k));
   }
}
