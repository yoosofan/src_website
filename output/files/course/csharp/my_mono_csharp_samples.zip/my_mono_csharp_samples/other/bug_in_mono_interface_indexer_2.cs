using System;
using System.Threading;
//using System.Threading.Tasks;
interface ImySimple{
	int fun1();
	int this[double index]{
		set;
		get;
	}
	int Next { set; get;}
}
class implementImyCls : ImySimple{
	public implementImyCls(int m=0){val = m;}
	int val;
	public int Next {
		set {val = value>0 ? value : 0;}
		get {val+=2; return Next;}
	}
	public int fun1() {return Next;}
	public int this[double index]{
		set{Next = (int) value;}
		get{Next = (int) index; /*      Here is error  */ return Next;}
	}
	
}
class simpleTestCls{
	public int i,j;
	public simpleTestCls(int m , int  n=0){ i = m ; j=n;}
	public simpleTestCls(){i=j=0;}
}
class testCls{
	static void Main(){
		simpleTestCls[] ar1= new simpleTestCls[3];
		int[] mma= new int [10];
		mma[0] =1;
		ar1[0]= new simpleTestCls(2);
		ar1[0].i=12;
		ar1[0].j=13;
		Console.WriteLine("{0}   :   {1} ", ar1[0].i , ar1[0].j);
		implementImyCls c1 = new implementImyCls();
		Console.WriteLine("{0}", c1.Next);
	}
}
