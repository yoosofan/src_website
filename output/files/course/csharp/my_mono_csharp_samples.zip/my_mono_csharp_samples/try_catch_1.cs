using System; using System.IO;
class Demo1 {
 static int f1(int n){ int i=1;    int[] ear = new int[2];
    if(n==2){
      FileStream inpf= new FileStream("text1.txt",FileMode.Open); inpf.Close();
    }else{
      for(i=0;i<n;i++)     ear[i] = i ;
      Console.WriteLine("End of loop");          i= n/i;
    }
    return i;
 }
 static void Main(){
   byte b1=(byte) 2; byte b2=3;
   for(int i=0 ; i<5 ; i++)
     try{
          checked{b1 *= b2;}
          f1(i);
          Console.WriteLine(i);
    }catch (DivideByZeroException e){   Console.WriteLine("Divide by zero"); }
     catch (IndexOutOfRangeException e){  Console.WriteLine("Out of range"); }
     catch(IOException e){           Console.WriteLine("Can not open file"); }
     catch{               Console.WriteLine("Unknown Exception occured");  } 
     finally{       Console.WriteLine(i+1);      }   }  }