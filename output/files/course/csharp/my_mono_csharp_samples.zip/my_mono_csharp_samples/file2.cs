using System;
using System.IO;
class ShowFile {
   static void Main(string[] args){
      int i;
      FileStream fin;
      string fileName;
      if(args.Length < 1) {
         Console.WriteLine("Enter name of file :");
         fileName = Console.ReadLine();
         if(fileName.Trim() == "")  // Trim removes white space in a string
            fileName = "file2.cs";
      }
      else
         fileName = args[0];
      try {
         fin = new FileStream(fileName, FileMode.Open);
      } catch(IOException exc) {
         Console.WriteLine("Cannot Open File");
         Console.WriteLine(exc.Message);
         return; // File can't be opened, so stop the program.
      }
      try { // Read bytes until EOF is encountered.
         do {
            i = fin.ReadByte();
            if(i != -1) Console.Write((char) i);
         } while(i != -1);
      } catch(IOException exc) {
         Console.WriteLine("Error Reading File");
         Console.WriteLine(exc.Message);
      } finally {
         fin.Close();
      }
   }
}
