// http://live.gnome.org/Vala/ValaForCSharpProgrammers
class SampleCollection<T>
{
    private T[] arr = new T[100];

    public T this[int i]
    {
        get { return arr[i]; }
        set { arr[i] = value; }
    }
}

class IndexerDemo
{
    static void Main(string[] args)
    {
        var stringCollection = new SampleCollection<string>();

        stringCollection[0] = "Hello, World";
        System.Console.WriteLine(stringCollection[0]);
    }
}
