using System;

class AsyncDemo
{
    delegate int BinaryOperator(int a, int b);

    static void Callback(IAsyncResult r)
    {
        BinaryOperator adder = (BinaryOperator) r.AsyncState;

        Console.WriteLine("Addition completed");
        Console.WriteLine("Result was: {0}", adder.EndInvoke(r));
    }

    static void Main()
    {
        BinaryOperator adder = (a,b) => { return a+b; };

        adder.BeginInvoke(4, 5, Callback, adder);

        /* wait */
//        Console.ReadLine();
    }
}
