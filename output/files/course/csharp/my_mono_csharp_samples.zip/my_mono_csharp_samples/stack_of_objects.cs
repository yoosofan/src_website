using System;
public class myStack{
	private int top;
	private object[] data = new object[10];
	
	public myStack(){
		top = -1;
	}
	public bool Push(object d){
		if(top>8)
			throw new Exception("Ahmad Yoosofan error report stack overflow");
		data[++top]=d;
		return true;
	}
	public object Pop(){
		if(top<0)
			throw new Exception("stack is empty");
		return data[top--];
	}
	public bool isEmpty(){
		if(top== -1) 
			return true;
		return false;
	}
	public bool isFull(){
		if(top==9)
			return true;
		return false;
	}
	public object Top(){
		return data[top];
	}
}
class myTest{
	static void Main(){
		myStack s1 = new myStack();
		s1.Push((object) 12);
		Console.WriteLine(" {0} ",(int) s1.Top());
		try{
			for(int i=0;i<12; i++)
				s1.Push((object)i);
		}
		catch(Exception e){
			Console.WriteLine("aaaaaaaaaa Error message is {0} "); 
			Console.WriteLine(e);
		}
	}
}
	
