using System;
delegate int myfDelegate(int i);
delegate void mygDelegate(int i , int j);

class Delegate2Cls{
   public static int f1(int i){ return i;}
   public static int f2(int i){ return i+1;}
   public static int f3(int j){ return j-1;}
   public void g1(int i , int j){Console.WriteLine("9:  "+(i+j));}
   public void g2(int a , int b){Console.WriteLine("10: "+(a-b));}
   public void g3(int i , int j){Console.WriteLine("11: "+(i*j));}
}
class mainCls{
   static void Main(){

      myfDelegate myf = Delegate2Cls.f1;
      int k=1 ;
      k=myf(k);
      Console.WriteLine("19: " + k);
      myf = Delegate2Cls.f2;
      k=myf(k);
      Console.WriteLine("22: "+k);
      myf = new myfDelegate(Delegate2Cls.f3); // You can use new for assigning new function to this delegate
      k=myf(k);
      Console.WriteLine("25: "+k);
      myfDelegate[] amyf = {Delegate2Cls.f1 , Delegate2Cls.f2 , Delegate2Cls.f3};
      foreach(myfDelegate my1 in amyf)
         Console.WriteLine("28: "+my1(k));
      Delegate2Cls dlg1 = new Delegate2Cls();
      mygDelegate myg = new mygDelegate(dlg1.g1);
      myg(2,3);
      myg = dlg1.g2;
      myg(2,3);
      mygDelegate[] myga = {dlg1.g1 , dlg1.g2 , dlg1.g3};
      foreach(mygDelegate myg1 in myga)
         myg1(2,3);
   }
}