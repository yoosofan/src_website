// gmcs  test1.cs
// mono  test1.exe
// geany Build -- Set Build Build
// compile
// "g:\Program Files\Mono-2.6.7\bin\mono.exe"  "g:\Program Files\Mono-2.6.7\lib\mono\2.0\gmcs.exe"  "%f"
//     See g:\Program Files\Mono-2.6.7\bin\gmcs.bat
// Execute
// "g:\Program Files\Mono-2.6.7\bin\mono.exe" "%e".exe
using System;


namespace myTest
{
    class Program
    {
        static void Main(string[] args)
        {
            long j;
            /*
            double d;
            decimal t;char m;float ff;uint uuf;ulong kk;
            d = 12;*/
            j = 16;
            testClass1 aa1 = new testClass1();
            Console.WriteLine("This is {0} a test",i);
            string st1 = Console.ReadLine();
            Console.WriteLine("String is :: {1} ::: {0}", aa1.f1(j), st1);
            st1 = Console.ReadLine();
        }
        static int i = 12;
    }
    class testClass1
    {
        public int test1;
        long t2;
        public testClass1()
        {
            t2 = 12;
        }/*
        public int f2(int i , params string[] mm ){
            var myList = new List<int>();
            myList.Add(1);
            myList.Add(2);
            myList.Add(3);
            foreach( var kk in myList)
                Console.WriteLine(kk);

            return i + Convert.ToInt32(mm[0]);

        }*/
        public long f1(long d)
        {
            return d + 1+t2;
        }
        public long mf2(long d)
        {
			return d+1;
		}
    }
}
