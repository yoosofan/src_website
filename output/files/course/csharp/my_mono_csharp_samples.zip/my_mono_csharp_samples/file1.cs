using System;
using System.IO;

///FileAccess.Read FileAccess.Write   FileAccess.ReadWrite
class file1Cls{
   static void Main(){
      FileStream fin = null;
      try{
         fin = new FileStream("file1.cs", FileMode.Open);
         fin.Close();
      }
      catch(IOException exc) { // catch all I/O exceptions
         Console.WriteLine(exc.Message);
         // Handle the error.
      }
      catch(Exception exc) { // catch any other exception
         Console.WriteLine(exc.Message);
   // Handle the error, if possible.
   // Rethrow those exceptions that you don't handle.
      }
   }
}

