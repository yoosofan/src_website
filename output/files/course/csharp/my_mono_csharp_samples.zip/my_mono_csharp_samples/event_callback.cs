// http://live.gnome.org/Vala/ValaForCSharpProgrammers
using System;

class AsyncDemo
{
    delegate int BinaryOperator(int a, int b);

    static int Adder(int a, int b)
    {
        return a + b;
    }

    static void Callback(IAsyncResult r)
    {
        BinaryOperator adder = (BinaryOperator) r.AsyncState;

        Console.WriteLine("Addition completed");
        Console.WriteLine("Result was: {0}", adder.EndInvoke(r));
    }

    static void Main()
    {
        BinaryOperator adder = Adder;

        adder.BeginInvoke(4, 5, Callback, adder);

        /* wait */
        Console.ReadLine();
    }
    /* only in C# 4
    public int Food(){
		int i;
		dynamic mm = 12;
		i=test123(mm);
		return i;
	}
	public int test123(int mm){
		return mm+1;
	}
	*/
}
