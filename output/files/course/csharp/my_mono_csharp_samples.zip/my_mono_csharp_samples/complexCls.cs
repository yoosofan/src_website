using System;

class complexCls{
   double r,i;

   public complexCls(int m=0 , int n=0){r=m;i=n;}
   public void Show(){Console.WriteLine(r+"+ i "+i);}
   public double Magnitude(){return Math.Sqrt(r*r+i*i);}

   public static complexCls operator +(complexCls a , complexCls b){
      complexCls result = new complexCls();
      result.r = a.r + b.r;
      result.i = a.i + b.i;
      return result;
   }
   public static complexCls operator +(complexCls a , double b){
      complexCls result = new complexCls();
      result.r = a.r + b;
      result.i = a.i;
      return result;
   }
   public static complexCls operator +(double b , complexCls a){
      complexCls result = new complexCls();
      result.r = a.r + b;
      result.i = a.i;
      return result;
   }
   public static complexCls operator -(complexCls a , complexCls b){
      complexCls result = new complexCls();
      result.r = a.r - b.r;
      result.i = a.i - b.i;
      return result;
   }
   public static complexCls operator -(complexCls a , double b){
      complexCls result = new complexCls();
      result.r = a.r - b;
      result.i = a.i;
      return result;
   }
   public static complexCls operator -(double b , complexCls a){
      complexCls result = new complexCls();
      result.r = b - a.r;
      result.i = a.i;
      return result;
   }
   public static complexCls operator *(complexCls a , complexCls b){
      complexCls result = new complexCls();
      result.r = a.r * b.r;
      result.i = a.i * b.i;
      return result;
   }
   public static complexCls operator *(complexCls a , double b){
      complexCls result = new complexCls();
      result.r = a.r * b;
      result.i = a.i;
      return result;
   }
   public static complexCls operator *(double b , complexCls a){
      complexCls result = new complexCls();
      result.r = a.r * b;
      result.i = a.i;
      return result;
   }
   public static bool operator ==(complexCls a , complexCls b){
      if(a.r == b.r & a.i == b.i)
         return true;
      return false;
   }
   public static bool operator !=(complexCls a , complexCls b){
      if(a.r == b.r & a.i == b.i) return false;
      return true;
   }
   public static bool operator ==(complexCls a , double b){
      if(a.i == 0 & a.r == b)
         return true;
      return false;
   }
   public static bool operator ==(double b , complexCls a){
      if(a.i == 0 & a.r == b)
         return true;
      return false;
   }
   public static bool operator !=(complexCls a , double b){
      if(a.i == 0 & a.r == b)
         return false;
      return true;
   }
   public static bool operator !=(double b , complexCls a){
      if(a.i == 0 & a.r == b)
         return false;
      return true;
   }
   public bool Equals(complexCls a){
      if(r == a.r & i == a.i)
         return true;
      return false;
   }
   public override bool Equals(Object a){
      if(a is complexCls)
         return Equals((complexCls)a);
      return false;
   }
   public override int GetHashCode(){
      return r.GetHashCode();
   }

   public static bool operator <(complexCls a , complexCls b){
      if(a.r < b.r & a.i < b.i)
         return true;
      return false;
   }
   public static bool operator <(complexCls a , double b){
      if(a.i == 0 & a.r < b)
         return true;
      return false;
   }
   public static bool operator <(double b , complexCls a){
      if(a.i == 0 & b < a.r )
         return true;
      return false;
   }
   public static bool operator >(complexCls a , complexCls b){
      if(a.r > b.r & a.i > b.i)
         return true;
      return false;
   }
   public static bool operator >(complexCls  a , double b){
      if(a.i == 0 & a.r > b)
         return true;
      return false;
   }
   public static bool operator >(double b , complexCls a){
      if(a.i == 0 && b > a.r )
         return true;
      return false;
   }
   public override string ToString(){ return r+"+ i "+i;}
   //To enable the use of the && and || short-circuit operators, you must follow four rules. First, the class must overload & and |. Second, the return type of the overloaded & and | methods must be the same as the class for which the operators are being overloaded. Third, each parameter must be a reference to an object of the class for which the operator is being overloaded. Fourth, the true and false operators must be overloaded for the class. When these conditions have been met, the short-circuit operators automatically become available for use.
   //public static implicit operator double(complexCls a){     return a.r; }


}
class mainCls{
   public static void Main(){
      complexCls a=new complexCls(2);
      complexCls b=new complexCls(3,2);
      //double aaa = a + 12;  //public static implicit operator double(complexCls a){return a.r; }
      //Console.WriteLine(aaa);
      a = b + 12;
      a.Show();
      Console.WriteLine(a);
      Console.WriteLine(a.Magnitude());
      Console.WriteLine("End normal");
   }
}

