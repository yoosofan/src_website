/* 
 * 
 * 
 * gmcs -pkg:dotnet hello.cs
 * 
 * 
 * http://zetcode.com/tutorials/monowinformstutorial/firststeps/
 */
using System;
using System.Drawing;
using System.Windows.Forms;

class MForm : Form {
	Button button2;
    public MForm() {
        Text = "Ahmad Yoosofan";
        Size = new Size(250, 200);

        Button button = new Button();

        button.Location = new Point(30, 20);
        button.Text = "Quit";
        button.Click += new EventHandler(OnClick);
        button.MouseEnter += new EventHandler(OnEnter);

        Controls.Add(button);
		button2 = new Button();

        button2.Location = new Point(100, 20);
        button2.Text = "Text";
        button2.Click += new EventHandler(OnClick2);
        button2.MouseEnter += new EventHandler(OnEnter2);

        Controls.Add(button2);        
        CenterToScreen();
    }

    void OnClick(object sender, EventArgs e) {
       Close();
    }

    void OnEnter(object sender, EventArgs e) {
       Console.WriteLine("Button Entered");
    }
    void OnClick2(object sender, EventArgs e) {
       button2.Text = "New ";
    }

    void OnEnter2(object sender, EventArgs e) {
       Console.WriteLine("Button2 Entered");
    }

}

class MApplication {
    public static void Main() {
        Application.Run(new MForm());
    }
}
