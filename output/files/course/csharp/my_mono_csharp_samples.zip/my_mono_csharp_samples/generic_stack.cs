using System;

delegate void myAction<dataType>(dataType m);

class myStack<dataType>{
	private int top;
	dataType[] data;
	private int max;
	public myStack(int l=10){
		this.top=-1;
		this.max=l;
		this.data = new dataType[max];
	}
	public bool Push(dataType d){
		if(top == max -1)
			throw new Exception("Stack overflow");
		data[++top]=d;
		return true;
	}
	public dataType Pop(){
		if(top == -1)
			throw new Exception("Stack is empty, you can't pop from it.");
		return data[top--];
	}
	public dataType Top(){
		if(top == -1)
			throw new Exception("Stack is empty");
		return data[top];
	}
	public bool isEmpty(){if(top == -1)    return true; else return false;}
	public bool isFull (){if(top == max-1) return true; else return false;}
	public void PushMultiple(params dataType[] values){
		foreach(var v in values) 	Push(v);
	//foreach(dataType v in values) Push(v);
	}
	//delegate void Action(dataType m);
	public void Traverse(myAction<dataType> f1){
		//foreach(var x in data)			f1(x);
		for(int i=top; i>=0 ; i--)
			f1(data[i]);
		
	}
	public void Empty(){top=-1;}
}
public class myTest{
	static void Main(){
		myStack<int> s1 = new myStack<int>(30);
		try{
			Console.WriteLine(s1.Push(14));
		}catch(Exception e){
			Console.WriteLine(e);
		}finally{
			Console.WriteLine("In Finally");
		}
		s1.Push(9);
		s1.Push(10);
		s1.Push(10);
		s1.Push(12);
		for(int i=0;i<4;i++)
			Console.WriteLine("s1[{0}] = "+s1.Pop().ToString() , i);
		try{
			for(int i=0;i<40;i++)
				s1.Push(i);
		}catch(Exception e){
			Console.WriteLine(e);
		}
		try{
			for(int i=0;i<40;i++)
				s1.Pop();
		}catch(Exception e){
			Console.WriteLine(e);
		}
		s1.Empty();
		s1.PushMultiple(12,11,14,15,23,45,564,667,123,76);
		s1.Traverse(delegate(int d){Console.WriteLine(d);});
		//while(!s1.isEmpty()) 			Console.WriteLine(s1.Pop());
	}
}
