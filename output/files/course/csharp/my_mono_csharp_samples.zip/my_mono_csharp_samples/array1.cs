using System;
using System.Threading;
//using System.Threading.Tasks;
class simpleTestCls{
	public int i,j;
	public simpleTestCls(int m , int  n=0){ i = m ; j=n;}
	public simpleTestCls(){i=j=0;}
}
class testCls{
	static void Main(){
		simpleTestCls[] ar1= new simpleTestCls[3];
		int[] mma= new int [10];
		mma[0] =1;
		ar1[0]= new simpleTestCls(2);
		ar1[0].i=12;
		ar1[0].j=13;
		Console.WriteLine("{0}   :   {1} ", ar1[0].i , ar1[0].j);
	}
}
