/*
 * Add two matrix which stored in a text file.
 * Author   :     Ahmad Yoosofan
 * Date     :     2010/12/29
 * In this program many standard function is used.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

double *readAfile(char * fileName, int *nr , int *nc);
void printMatrix(double *arx , int nr , int nc);
int extractMatrices(double *arx, double **matrix, int *nr , int *nc, int numberOfMatrices);
void criticalErrorReport(char *msg){printf("%s\n",msg);exit(0);}
double* addSeveralMatrix(double *matrix1[], int numberOfMatrices , int *nr , int *nc);
int checkConsistencyForAdding(int *nr, int *nc, int numberOfMatrices);
int main(){
   char fileName[] = "inputMatrixFile.txt" ;
   double *arx=0, *matrix[2]={0,0} , *matrix2=0;
   int nc[2]={0,0} , nr[2]={0,0} , i;
   arx = readAfile(fileName, nr, nc);
   extractMatrices(arx,matrix, nr , nc, 2);
   free(arx);
   matrix2 = addSeveralMatrix(matrix, 2, nr, nc);
   if(matrix2){
      printMatrix(matrix[0], nr[0], nc[0]);
      printMatrix(matrix[1], nr[1], nc[1]);
      printMatrix(matrix2, nr[1], nc[1]);
   }
   for(i=0;i<2;i++) free(matrix[i]);
   free(matrix2);
   return 0;
}
double* addSeveralMatrix(double *matrix1[], int numberOfMatrices , int *nr , int *nc){
   double *matrix2=0;
   int k, whichMatrix ,  numberOfElementsInMatrix;
   numberOfElementsInMatrix = nr[0] * nc[0] ;
   if(!checkConsistencyForAdding(nr, nc, numberOfMatrices)){
      matrix2= (double*)malloc(numberOfElementsInMatrix*sizeof(double));
      if(!matrix2) printf("Can not allocate memory for matrix2 in addSeveralMatrix.\n");
      else{
         for(k=0;k<nr[0]*nc[0];k++)
            matrix2[k] = matrix1[0][k] ;
         for(whichMatrix=1 ;whichMatrix<numberOfMatrices;whichMatrix++)
            for(k=0; k < numberOfElementsInMatrix; k++)
               matrix2[k] += matrix1[whichMatrix][k];
      }
   }
   return matrix2;
}
void printMatrix(double *arx , int nr, int nc){
   int i , j , k=0 ;
      for(i=0;i<nr;i++){
         for(j=0;j<nc ; j++)
            printf("%lf\t", arx[k++]);
         printf("\n");
      }
      printf("\n");
}
int extractMatrices(double *arx, double **matrix, int *nr , int *nc , int numberOfMatrices){
   int i , j , k=0 , whichMatrix=0 , m;
   for(whichMatrix=0; whichMatrix<numberOfMatrices; whichMatrix++){
      m=0 ;
      matrix[whichMatrix] = (double *)malloc(nr[whichMatrix]*nc[whichMatrix]*sizeof(double));
      if(matrix[whichMatrix] == 0 )
         criticalErrorReport("Can not allocate memory in extractMatrices");
      for(i=0; i<nr[whichMatrix] ; i++)
         for(j=0; j<nc[whichMatrix]; j++)
            matrix[whichMatrix][m++] = arx[k++];
   }
   return 1;
}

void inconsistentErrorReport(char *msg , int numberOfLine, int nctemp,  int *nr , int *nc , int whichMatrix){
   printf("Error, %s\n",msg);
   printf("Line number is %d \n", numberOfLine);
   printf("Number of columns is %d , row number is %d , columns number is %d " ,
      nctemp, nr[whichMatrix] , nc[whichMatrix] );
   printf("matrix number is %d \n" , whichMatrix);
   exit(0);

}
int extractIntegersInALine(char *line , double *arx , int index){
   char *spos ;
   int nctemp = 0;
   double x;
   x=  strtod(line , &spos);
   while(line != spos){
      arx[index++] = x ;
      nctemp ++;
      line = spos;
      x = strtod(line , &spos);
   }
   return nctemp;

}
int allocateMemory(FILE *fp , double **arx , char **line){
   int flag=1 , sz ;
   fseek(fp,0,SEEK_END);    sz = ftell(fp); rewind(fp);
   if(sz){
      sz = sz / 2 + 1;
      if(!(*line = (char *) malloc(sz * sizeof(char))))
         printf("Can not allocate memory %d \n",sz);
      else
         if((*arx = (double *)malloc(sz * sizeof(double)))!=0)   flag = 0;
         else printf("Can not allocate memory for arx \n");
   }
   else  printf("size of file is zero ! \n");
   if(flag) sz = 1 ;
   return sz - 1 ;
}
int evaluateRowsAndColumns(int *nc , int *nr , int *whichMatrix, int nctemp, int numberOfLine){
   int flag = 0;
   if(nctemp){
      if(nr[*whichMatrix]){
         if(nctemp != nc[*whichMatrix]){
            flag = 1 ;
            inconsistentErrorReport(
               "inconsistent matrix with different number of columns in each rows.",
               numberOfLine , nctemp, nr , nc , *whichMatrix);
         }
      }else nc[*whichMatrix]=nctemp;
      nr[*whichMatrix] ++ ;
   }
   else
      if(nr[*whichMatrix]) *whichMatrix = 1 ;
   return flag ;
}
int checkConsistencyForAdding(int *nr, int *nc, int numberOfMatrices){
   int flag = 0 , i;
   char buf[1000];
   strcpy(buf, "has different number of ");
   for(i=0;i<numberOfMatrices;i++){
      if(nr[0] != nr[i]) flag = 1;
      if(nc[0] != nc[i]) flag = 2;
      if(flag) break;
   }
   if(flag){
      strcat(buf , flag ==1 ?  "rows " : "columns ");
      strcat(buf,"in matrix. ");
      printf(" %d's matrix %s .\n",i+1,buf);
   }
   return flag;
}

double* readAfile(char * fileName,int *nr , int *nc){
   FILE *fp;
   int sz , index = 0 , nctemp=0;
   int whichMatrix = 0 ,numberOfLine = 0, flag =1;
   char *line ;
   double *arx;
   if(!(fp = fopen(fileName , "r")))
   { printf("Can not open input file %s\n",fileName); exit(0); }
   if(!(sz=allocateMemory(fp,&arx,&line))) exit(0);
   fgets(line , sz , fp);
   while(!feof(fp)){
      numberOfLine++;
      index += nctemp = extractIntegersInALine(line , arx , index);
      flag=evaluateRowsAndColumns(nc, nr, &whichMatrix, nctemp,numberOfLine);
      fgets(line , sz , fp);
   }
   fclose(fp);
   index += nctemp = extractIntegersInALine(line , arx , index);
   if(nctemp){
      numberOfLine ++;
      evaluateRowsAndColumns(nc, nr, &whichMatrix, nctemp, numberOfLine);
   }
   free(line);
   //printf("%d %d %d %d  %d %d\n",nc[0] , nc[1] , nr[0] , nr[1], index , whichMatrix );
   //for(sz=0;sz<index ; sz++)      printf("%lf\n",arx[sz]);
   return arx;
}
